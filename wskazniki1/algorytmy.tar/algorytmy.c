#include<stdio.h>
#include<stdlib.h>

struct lista
{
    int number;
    struct lista *next;
    struct lista *previous;
};

typedef struct lista wsk;
wsk *head=NULL, *tail=NULL;

wsk* nowyWskaznik(int val);
void insert_at_tail(int value);
void insert_at_first(int value);
void printLinkedListForward();
int selectTail();
int selectPositionTail();
void deleteNode();
int main()
{
    int d = 23, e = 12, f = 66, g = 99, h =65, i = 20, j = 8;




    printf("Dodano na koniec: %d, %d, %d, %d, %d, %d  \n", d, e, g, h, i, j);
    insert_at_tail(d);
    insert_at_tail(e);
    insert_at_tail(g);
    insert_at_tail(h);
    insert_at_tail(i);
    insert_at_tail(j);

    //print the list forward
    printLinkedListForward();

    printf("Dodano na początek: %d\n", selectTail());
    deleteNode();
    printLinkedListForward();
    return 0;
}

//create a new node and returns to caller
wsk* nowyWskaznik(int val)
{
    wsk *temp_wsk;
    temp_wsk = (wsk *) malloc(sizeof(wsk));
    temp_wsk->number=val;
    temp_wsk->next=NULL;
    temp_wsk->previous=NULL;

    return temp_wsk;
}

//Insert a node after last node
void insert_at_tail(int value)
{
  wsk  *newWsk = nowyWskaznik(value);

    if(head==NULL) //For the 1st element
    {
        head=newWsk;
        tail=newWsk;
        return;
    }

    //'tail' is a global node. 'newNode' will be the next node of tail.
    //finally newNode will be the 'tail' node of the list
    tail->next = newWsk;
    newWsk->previous = tail; //'newNode' point 'tail' node as previous node
    tail = newWsk; // update the global node 'tail' by newNode.
}

void deleteNode(){
   wsk *myList;
   wsk *poczatek;
   poczatek = head;
   myList = tail;

         if(myList->next==NULL){ // desired node is the last node of list
             myList->next = head;
             head = myList;
             tail = myList->previous;
             }
    }

//Insert a node at front of the list. This node will be the new head
void insert_at_first(int value)
{
    wsk *newWsk = nowyWskaznik(value);

    if(head==NULL) //For the 1st element
    {
        //For now, newNode is the only one node of list
        //So it it is head and also tail
        head=newWsk;
        tail=newWsk;
        return;
    }

    //newNode will be the NEW HEAD of list.
    //So it'll point to head as 'next node'
    newWsk->next = head;
    head->previous = newWsk; //before, the previous node of head was NULL. but now newNode

    head = newWsk; //update the global node 'head' by newNode
    deleteNode();
}
int selectTail()
{
  wsk *myList;
   myList = tail;
   return myList->number;
}


void printLinkedListForward()
{
    printf("\nYour updated linked list in FORWARD ORDER:\n");

    wsk *myList;
    myList = head;

    while(1)
    {
        if(head==NULL || tail==NULL) break;

        printf("%d ", myList->number);

        if(myList==tail) break;

        myList = myList->next;

    }
    puts("\n");
}
